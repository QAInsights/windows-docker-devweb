from mitmproxy import ctx
from mitmproxy import http
from mitmproxy import addonmanager


class NetworkDumper:
    ScriptAddons = []
    started = False

    def __init__(self) -> None:
        super().__init__()
        self.counter = 0

    def load(self, entry: addonmanager.Loader):
        ctx.log.debug("AddOn: Network Dumper - Loaded")

    def request(self, flow: http.HTTPFlow):
        url = flow.request.url
        if "shutdown.devweb" in url:
            ctx.log.debug("Closing proxy")
            flow.reply.kill(True)
            # Start of workaround. issue [3572] (https://github.com/mitmproxy/mitmproxy/issues/3572)
            ctx.master.addons.trigger("done")
            # End of workaround. issue [3572] (https://github.com/mitmproxy/mitmproxy/issues/3572)
            ctx.master.shutdown()

    #  TODO: maybe load dumpers per flag in options
    def running(self):
        if self.started is False:
            self.started = True
            ctx.log.info("Press any key to stop the recording")
        # TODO: Due to issue in mitmproxy 3.0.4 that calls this event twice - remove once resolved

    def init_addons(self):
        from WebSocketHarDumper import WebSocketHarDumper
        from HttpHarDumper import HttpHarDumper
        from HarWriter import HarWriter

        writer = HarWriter()
        web_socket_har_dumper = WebSocketHarDumper(writer)
        http_har_dumper = HttpHarDumper(writer)
        self.ScriptAddons = [web_socket_har_dumper, http_har_dumper, writer]

    def done(self):
        if self.counter > 0:
            return
        self.counter += 1
        for i in self.ScriptAddons:
            if hasattr(i, "final"):
                i.final()


networkDumper = NetworkDumper()
networkDumper.init_addons()
addons = networkDumper.ScriptAddons
addons += [networkDumper]
