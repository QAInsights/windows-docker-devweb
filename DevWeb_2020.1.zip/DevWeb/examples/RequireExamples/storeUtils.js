module.exports = (load) => {
  return {
    buySomething(){
      load.log('You bought an item!');
    }
  }
}