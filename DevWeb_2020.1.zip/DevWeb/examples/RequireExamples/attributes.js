module.exports = {
  doLogin: true,
  buySomethingChance: 50,
  otherAttribute: 'Hello'
};