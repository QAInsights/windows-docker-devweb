module.exports = (load) => {

    //Some additional code used in this file only
    function addOne(value) {
        return value + 1;
    }

    //This will be exported from the file
    return {
        loginUser(username) {
            load.log(`The user ${username} logged in`);
        },

        logoutUser(username) {
            load.log(`Bye bye ${username}`);
        }
    }
};