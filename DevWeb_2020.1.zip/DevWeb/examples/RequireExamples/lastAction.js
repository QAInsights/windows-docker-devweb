module.exports = (load) => {
    load.action("The last action", () => {
        load.log("This is the very last action!");
    })
};