module.exports = (load) => {
    load.action("My Firtst Action", () => {
        load.log("First action is here");
    })
};