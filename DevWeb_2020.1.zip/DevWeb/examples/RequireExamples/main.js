load.initialize(async function() {
	load.log("Initial Action");                	
});

require("./extraActions")(load);

load.action('Main Action', async function () {
	
    load.log("Main Action");
    const attributes = require('./attributes.js');
    const {loginUser, logoutUser} = require('./userUtils.js')(load);
    const {buySomething} = require('./storeUtils.js')(load);

    if (attributes.doLogin) {
        const username = 'John';
        loginUser(username);

        if (attributes.buySomethingChance < Math.random() * 100) {
            buySomething();
        }

        logoutUser(username);
    } else {
        load.log('Nothing to do :(');
    }

    load.sleep(2);
});

require('./lastAction')(load);

load.finalize(async function() {
	load.log("Final Action");  
});
