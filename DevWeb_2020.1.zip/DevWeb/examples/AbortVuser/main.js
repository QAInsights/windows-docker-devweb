load.initialize(async function () {
});

load.action("Action", async function () {
    load.log('This line will be in the log because it is before abort');

    load.exit(load.ExitType.stop);

    load.log('This line is not in the log because it is after the abort');
});

load.finalize(async function () {
});

