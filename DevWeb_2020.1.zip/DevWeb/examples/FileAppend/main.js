const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');

function randomString(length) {
    if (!length) {
        length = Math.floor(Math.random() * chars.length);
    }

    let result = [];
    result.length = length;
    for (let i = 0; i < length; i++) {
        result[i] = chars[Math.floor(Math.random() * chars.length)];
    }
    return result.join('');
}

load.initialize(async function () {
});

load.action("Action", async function () {
    const txtFileName = '/abc' + Date.now() + '.txt';
    const buffer = randomString(2048);

    const myFile = new load.File(txtFileName);
    myFile.append(buffer);

    const checkContent = myFile.read(
        {
            "returnContent": false,
            extractors: [
                new load.TextCheckExtractor("checkAppend", buffer)
            ]
        }
    );
});

load.finalize(async function () {
});
