load.action("Action3", async function () {
    load.log('action:Action3');
});