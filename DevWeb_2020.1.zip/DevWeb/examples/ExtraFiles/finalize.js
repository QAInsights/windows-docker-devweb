load.finalize("fin", async function () {
    load.log("This is finalize");
});
