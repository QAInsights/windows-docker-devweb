load.initialize("init", async function () {
    load.log("This is initialize");
});
