
load.action("Action", async function () {
    load.log("Hello DevWeb");
});

